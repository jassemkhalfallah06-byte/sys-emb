const int inter=1;
const int lamp=7;
void setup()
{
  pinMode(inter,INPUT);
  pinMode(lamp,OUTPUT);
}

void loop()
{
  const int etat=digitalRead(inter);
  if (etat==LOW)
  {
    digitalWrite(lamp,HIGH);
  }
  else
  {
    digitalWrite(lamp,LOW);
  }
}
