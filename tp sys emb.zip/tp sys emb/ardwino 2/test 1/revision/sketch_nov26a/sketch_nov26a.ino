const int inter1=1;
const int inter2=6;
const int led1=2;
const int led2=7;
void setup()
{
  pinMode(inter1,INPUT);
  pinMode(inter2,INPUT);
  pinMode(led1,OUTPUT);
  pinMode(led2,OUTPUT);
}

void loop()
{
  const int etat1=digitalRead(inter1);
  const int etat2=digitalRead(inter2);
  digitalWrite(led1,LOW);
  digitalWrite(led2,LOW);
  if (etat1==LOW && etat2==LOW)
  {
    digitalWrite(led1,LOW);
    digitalWrite(led2,LOW);
  }
  else if (etat1==LOW && etat2==HIGH)
  {
    digitalWrite(led1,HIGH);
    digitalWrite(led2,HIGH);
  }
  else if (etat1==HIGH && etat2==LOW)
  {
    digitalWrite(led1,HIGH);
    digitalWrite(led2,LOW);
  }
  else if (etat1==HIGH && etat2==HIGH)
  {
    digitalWrite(led1,LOW);
    digitalWrite(led2,HIGH);
  }
  else
  {
    digitalWrite(led1,LOW);
    digitalWrite(led2,LOW);
  }
}
