int A=6;
int B=5;
int C=4;
int D=3;
int E=2;
int F=1;
int G=0;
int inter1=13;
int inter2=12;
int inter3=11;
int inter4=10;
int inter5=9;
int inter6=8;
int inter7=7;
void setup()
{
  pinMode(inter1,INPUT);
  pinMode(inter2,INPUT);
  pinMode(inter3,INPUT);
  pinMode(inter4,INPUT);
  pinMode(inter5,INPUT);
  pinMode(inter6,INPUT);
  pinMode(inter7,INPUT);
  pinMode(A,OUTPUT);
  pinMode(B,OUTPUT);
  pinMode(C,OUTPUT);
  pinMode(D,OUTPUT);
  pinMode(E,OUTPUT);
  pinMode(F,OUTPUT);
  pinMode(G,OUTPUT);
}

void loop()
{
  int etat1=digitalRead(inter1);
  int etat2=digitalRead(inter2);
  int etat3=digitalRead(inter3);
  int etat4=digitalRead(inter4);
  int etat5=digitalRead(inter5);
  int etat6=digitalRead(inter6);
  int etat7=digitalRead(inter7);
  if (etat1==HIGH)
  {
    digitalWrite(A,HIGH);
  }
  else
  {
    digitalWrite(A,LOW);
  }
  if (etat2==HIGH)
  {
    digitalWrite(B,HIGH);
  }
  else
  {
    digitalWrite(B,LOW);
  }
  if (etat3==HIGH)
  {
    digitalWrite(C,HIGH);
  }
  else
  {
    digitalWrite(C,LOW);
  }
  if (etat4==HIGH)
  {
    digitalWrite(D,HIGH);
  }
  else
  {
    digitalWrite(D,LOW);
  }
  if (etat5==HIGH)
  {
    digitalWrite(E,HIGH);
  }
  else
  {
    digitalWrite(E,LOW);
  }
  if (etat6==HIGH)
  {
    digitalWrite(F,HIGH);
  }
  else
  {
    digitalWrite(F,LOW);
  }
  if (etat7==HIGH)
  {
    digitalWrite(G,HIGH);
  }
  else
  {
    digitalWrite(G,LOW);
  }
}
