const int inter=2;
const int lamp=13;
void setup()
{
  pinMode(inter,INPUT);
  pinMode(lamp,OUTPUT);
}

void loop()
{
  int etat=digitalRead(inter);
  if (etat==HIGH)
  {
    delay(1000);
    digitalWrite(lamp,HIGH);
  }
  else
  {
    digitalWrite(lamp,LOW);
  }
}
