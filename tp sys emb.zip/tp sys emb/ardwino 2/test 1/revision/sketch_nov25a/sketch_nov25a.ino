const int pinInter = 7;
const int pinlamp = 1;
const int x=5;
int i;
void setup()
{
  pinMode(pinInter,INPUT);
  pinMode(pinlamp,OUTPUT);
  digitalWrite(pinlamp,LOW);
}

void loop()
{
  int etat=digitalRead(pinInter);
  if (etat==HIGH)
  {
    for (i=0;i<x;i++)
    {
      digitalWrite(pinlamp,HIGH);
      delay(1);
      digitalWrite(pinlamp,LOW);
    }
  }
  else if (etat==LOW)
  {
    digitalWrite(pinlamp,LOW);
  }
  else
  {
    digitalWrite(pinlamp,LOW);
  }
}
