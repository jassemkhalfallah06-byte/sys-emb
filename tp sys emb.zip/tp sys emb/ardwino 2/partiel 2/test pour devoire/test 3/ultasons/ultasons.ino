#include <LiquidCrystal.h>

// On garde ton câblage LCD actuel
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

const int trigPin = 9;  // Broche Trig
const int echoPin = 8;  // Broche Echo

void setup() {
  pinMode(trigPin, OUTPUT); // Trig est une sortie
  pinMode(echoPin, INPUT);  // Echo est une entrée
  Serial.begin(9600);
  lcd.begin(16, 2);
}

void loop() {
  // 1. Envoyer une impulsion de 10 microsecondes
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  // 2. Mesurer le temps de l'écho (en microsecondes)
  long duree = pulseIn(echoPin, HIGH);

  // 3. Calculer la distance (Vitesse du son = 340 m/s ou 0.034 cm/us)
  // On divise par 2 car le son fait l'aller-retour
  int distance = duree * 0.034 / 2;

  // 4. Affichage



  
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Dist: ");
  lcd.print(distance);
  lcd.print(" cm");

  Serial.print("Distance: ");
  Serial.println(distance);

  delay(500);
}
