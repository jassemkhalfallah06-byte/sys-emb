#include <LiquidCrystal.h>

// Initialisation du LCD (Broches selon schéma ISIS classique)
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

const int pinPot = A0; // Branche le milieu du potentiomètre sur A0

void setup() {
  Serial.begin(9600);
  lcd.begin(16, 2);
  lcd.setCursor(0, 0);
  lcd.print("Valeur Analog:");
}

void loop() {
  // 1. Lecture
  int lecture = analogRead(pinPot);
  
  // 2. Affichage Moniteur Série
  Serial.print("Valeur lue : ");
  Serial.println(lecture);
  
  // 3. Affichage LCD
  lcd.setCursor(0, 1); // Aller à la deuxième ligne
  lcd.print("      ");  // Effacer l'ancienne valeur
  lcd.setCursor(0, 1);
  lcd.print(lecture);
  
  delay(500); // Pause de 500ms pour la lisibilité
}
