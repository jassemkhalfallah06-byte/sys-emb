#include <LiquidCrystal.h>

// Configuration du LCD selon votre câblage image_efb1fb.png
// RS=12, E=11, D4=5, D5=4, D6=3, D7=2
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

const int pinPot = A0;   // Entrée pour le potentiomètre
const int pinTemp = A1;  // Entrée pour le capteur LM35

void setup() {
  // Initialisation du moniteur série
  Serial.begin(9600);
  
  // Initialisation du LCD (16 colonnes, 2 lignes)
  lcd.begin(16, 2);
  lcd.print("Systeme Pret");
  delay(1000);
  lcd.clear();
}

void loop() {
  // --- 1. LECTURE ANALOGIQUE ---
  int valeurPot = analogRead(pinPot);
  
  // Lecture LM35 et conversion en Celsius
  // Formule : (Valeur ADC * 5.0 / 1024.0) * 100
  int lectureTemp = analogRead(pinTemp);
  float tension = lectureTemp * (5.0 / 1024.0);
  float celsius = tension * 100.0;

  // --- 2. MONITEUR SÉRIE ---
  Serial.print("Pot: ");
  Serial.print(valeurPot);
  Serial.print(" | Temp: ");
  Serial.print(celsius);
  Serial.println(" C");

  // --- 3. AFFICHAGE LCD ---
  lcd.setCursor(0, 0);
  lcd.print("Pot: ");
  lcd.print(valeurPot);
  lcd.print("     "); // Efface les restes de chiffres

  lcd.setCursor(0, 1);
  lcd.print("Temp: ");
  lcd.print(celsius, 1); // 1 chiffre après la virgule
  lcd.print(" C   ");

  delay(500); // Mise à jour toutes les 0.5s
}
