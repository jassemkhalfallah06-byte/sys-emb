#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);
const int t = 9;
const int e = 10;
const int ledVerte = 2;
const int ledRouge = 3;
long du;
int d;
int c = 0;
bool car = false;

void setup() {
  // put your setup code here, to run once:
  pinMode(t, OUTPUT);
  pinMode(e, INPUT);
  pinMode(ledVerte, OUTPUT);
  pinMode(ledRouge, OUTPUT);

  lcd.init();
  lcd.backlight();
  digitalWrite(ledRouge, HIGH);
  digitalWrite(ledVerte, LOW);
  lcd.setCursor(0, 0);
  lcd.print("Parking");
  delay(2000);
  updateDisplay();
}

void loop() {
  // put your main code here, to run repeatedly:
  digitalWrite(t, LOW);
  delayMicroseconds(2);
  digitalWrite(t, HIGH);
  delayMicroseconds(10);
  digitalWrite(t, LOW);
  du = pulseIn(e, HIGH);
  d = du * 0.034 / 2;
  if (d <= 100 && d > 0 && !car) {
    car = true;
    c++;
    digitalWrite(ledRouge, LOW);
    digitalWrite(ledVerte, HIGH);
    updateDisplay();
    delay(40000); 
    digitalWrite(ledVerte, LOW);
    digitalWrite(ledRouge, HIGH);
    
    car = false;
     }
}
void updateDisplay() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Voitures: ");
  lcd.print(car);
  lcd.setCursor(0, 1);
  if (car) {
    lcd.print("Barriere: Ouverte");
  } else {
    lcd.print("Barriere: Fermee");
  }
}
