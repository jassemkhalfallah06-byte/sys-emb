int led = 3;
int potmet = A0;

void setup() {
  pinMode(led,OUTPUT);
  pinMode(potmet,INPUT); 
  Serial.begin(9600);
}

void loop() {
  int stat = analogRead(potmet);
  int val = map(stat,0,1023,0,255);
  analogWrite(led,val);
  Serial.println(val);
  delay(1000);
}
