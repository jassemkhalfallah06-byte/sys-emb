int A=8;
int B=7;
int C=6;
int D=5;
int E=4;
int F=3;
int G=2;
int H=1;
void setup()
{
  pinMode(A,OUTPUT);
  pinMode(B,OUTPUT);
  pinMode(C,OUTPUT);
  pinMode(D,OUTPUT);
  pinMode(E,OUTPUT);
  pinMode(F,OUTPUT);
  pinMode(G,OUTPUT);
}
void loop()
{
  digitalWrite(A,HIGH);
  delay(500);
  digitalWrite(A,LOW);
  digitalWrite(B,HIGH);
  delay(500);
  digitalWrite(B,LOW);
  digitalWrite(C,HIGH);
  delay(500);
  digitalWrite(C,LOW);
  digitalWrite(D,HIGH);
  delay(500);
  digitalWrite(D,LOW);
  digitalWrite(E,HIGH);
  delay(500);
  digitalWrite(E,LOW);
  digitalWrite(F,HIGH);
  delay(500);
  digitalWrite(F,LOW);
  digitalWrite(G,HIGH);
  delay(500);
  digitalWrite(G,LOW);
  digitalWrite(H,HIGH);
  delay(500);
  digitalWrite(H,LOW);
}
