int capt = A0;
void setup() {
  pinMode(capt,INPUT); 
  Serial.begin(9600);
}

void loop() {
  int stat = analogRead(capt);
  float x=(stat*500.0)/1023;
  Serial.println(x);
  delay(300);
}
